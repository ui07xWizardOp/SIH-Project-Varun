import { useState } from 'react';
import { 
  BarChart3, 
  MapPin, 
  AlertTriangle, 
  MessageSquare, 
  Shield, 
  Users, 
  Settings,
  Menu,
  X,
  Waves
} from 'lucide-react';
import { Button } from './ui/button';

type UserRole = 'citizen' | 'official' | 'moderator' | 'responder' | 'analyst' | 'policy';
type ViewType = 'dashboard' | 'report' | 'analytics' | 'verification' | 'alerts' | 'community';

interface SidebarProps {
  activeView: ViewType;
  onViewChange: (view: ViewType) => void;
  userRole: UserRole;
}

export function Sidebar({ activeView, onViewChange, userRole }: SidebarProps) {
  const [isCollapsed, setIsCollapsed] = useState(false);

  const getNavigationItems = () => {
    const commonItems = [
      { id: 'dashboard', label: 'Dashboard', icon: BarChart3 },
      { id: 'alerts', label: 'Alert Center', icon: AlertTriangle },
    ];

    const roleSpecificItems = {
      citizen: [
        { id: 'report', label: 'Report Hazard', icon: MapPin },
        { id: 'community', label: 'Community', icon: Users },
      ],
      official: [
        { id: 'analytics', label: 'Analytics', icon: BarChart3 },
        { id: 'verification', label: 'Verification', icon: Shield },
        { id: 'community', label: 'Community', icon: Users },
      ],
      moderator: [
        { id: 'verification', label: 'Verification', icon: Shield },
        { id: 'community', label: 'Community', icon: MessageSquare },
        { id: 'analytics', label: 'Analytics', icon: BarChart3 },
      ],
      responder: [
        { id: 'report', label: 'Field Reports', icon: MapPin },
        { id: 'community', label: 'Community', icon: Users },
      ],
      analyst: [
        { id: 'analytics', label: 'Analytics', icon: BarChart3 },
        { id: 'verification', label: 'Data Review', icon: Shield },
      ],
      policy: [
        { id: 'analytics', label: 'Analytics', icon: BarChart3 },
        { id: 'community', label: 'Reports', icon: MessageSquare },
      ],
    };

    return [...commonItems, ...roleSpecificItems[userRole]];
  };

  const navigationItems = getNavigationItems();

  return (
    <>
      {/* Mobile overlay */}
      {!isCollapsed && (
        <div className="fixed inset-0 bg-black bg-opacity-50 z-40 lg:hidden" onClick={() => setIsCollapsed(true)} />
      )}
      
      <aside className={`
        fixed top-0 left-0 h-full bg-white border-r border-blue-100 z-50 
        transition-all duration-300 ease-in-out shadow-xl
        ${isCollapsed ? '-translate-x-full lg:translate-x-0 lg:w-16' : 'translate-x-0 w-64'}
        lg:relative lg:translate-x-0
      `}>
        {/* Header */}
        <div className="flex items-center justify-between p-4 border-b border-blue-100 bg-gradient-to-r from-blue-50 to-cyan-50">
          {!isCollapsed && (
            <div className="flex items-center space-x-3">
              <div className="w-8 h-8 bg-gradient-to-br from-blue-600 to-cyan-600 rounded-lg flex items-center justify-center">
                <Waves className="h-5 w-5 text-white" />
              </div>
              <div>
                <h1 className="text-lg text-blue-900 tracking-tight">Project Varun</h1>
                <p className="text-xs text-blue-600 uppercase tracking-wider">INCOIS Platform</p>
              </div>
            </div>
          )}
          
          <Button
            variant="ghost"
            size="sm"
            onClick={() => setIsCollapsed(!isCollapsed)}
            className="lg:hidden"
          >
            {isCollapsed ? <Menu className="h-4 w-4" /> : <X className="h-4 w-4" />}
          </Button>
        </div>

        {/* User Role Badge */}
        {!isCollapsed && (
          <div className="p-4 border-b border-blue-100">
            <div className="bg-blue-50 rounded-lg p-3">
              <p className="text-xs text-blue-600 uppercase tracking-wider mb-1">Current Role</p>
              <p className="text-sm text-blue-900 capitalize">{userRole}</p>
            </div>
          </div>
        )}

        {/* Navigation */}
        <nav className="p-4 space-y-2">
          {navigationItems.map((item) => {
            const Icon = item.icon;
            const isActive = activeView === item.id;
            
            return (
              <button
                key={item.id}
                onClick={() => onViewChange(item.id as ViewType)}
                className={`
                  w-full flex items-center space-x-3 px-3 py-2.5 rounded-lg
                  transition-all duration-200 group
                  ${isActive 
                    ? 'bg-gradient-to-r from-blue-600 to-cyan-600 text-white shadow-lg' 
                    : 'text-gray-600 hover:bg-blue-50 hover:text-blue-700'
                  }
                  ${isCollapsed ? 'justify-center' : 'justify-start'}
                `}
              >
                <Icon className={`h-5 w-5 ${isActive ? 'text-white' : 'text-gray-500 group-hover:text-blue-600'}`} />
                {!isCollapsed && (
                  <span className="text-sm">{item.label}</span>
                )}
              </button>
            );
          })}
        </nav>

        {/* Settings */}
        {!isCollapsed && (
          <div className="absolute bottom-4 left-4 right-4">
            <button className="w-full flex items-center space-x-3 px-3 py-2.5 rounded-lg text-gray-600 hover:bg-blue-50 hover:text-blue-700 transition-all duration-200">
              <Settings className="h-5 w-5" />
              <span className="text-sm">Settings</span>
            </button>
          </div>
        )}

        {/* Collapsed mode toggle button */}
        {isCollapsed && (
          <div className="hidden lg:block absolute bottom-4 left-2">
            <Button
              variant="ghost"
              size="sm"
              onClick={() => setIsCollapsed(false)}
              className="w-12 h-12 rounded-lg"
            >
              <Menu className="h-4 w-4" />
            </Button>
          </div>
        )}
      </aside>

      {/* Mobile menu button */}
      <div className="lg:hidden fixed top-4 left-4 z-60">
        <Button
          variant="outline"
          size="sm"
          onClick={() => setIsCollapsed(false)}
          className="bg-white shadow-lg border-blue-200"
        >
          <Menu className="h-4 w-4" />
        </Button>
      </div>
    </>
  );
}