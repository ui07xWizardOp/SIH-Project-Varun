import { useState } from 'react';
import { Sidebar } from './components/Sidebar';
import { MapDashboard } from './components/MapDashboard';
import { ReportingInterface } from './components/ReportingInterface';
import { AnalyticsDashboard } from './components/AnalyticsDashboard';
import { AlertCenter } from './components/AlertCenter';
import { Toaster } from './components/ui/sonner';

type UserRole = 'citizen' | 'official' | 'moderator' | 'responder' | 'analyst' | 'policy';
type ViewType = 'dashboard' | 'report' | 'analytics' | 'verification' | 'alerts' | 'community';

export default function App() {
  const [currentView, setCurrentView] = useState<ViewType>('dashboard');
  const [userRole, setUserRole] = useState<UserRole>('official'); // Demo: start as official

  const renderView = () => {
    switch (currentView) {
      case 'dashboard':
        return <MapDashboard />;
      case 'report':
        return <ReportingInterface />;
      case 'analytics':
        return <AnalyticsDashboard />;
      case 'alerts':
        return <AlertCenter />;
      case 'verification':
        return (
          <div className="p-6">
            <h1 className="text-3xl mb-4">Verification Center</h1>
            <p className="text-gray-600">Coming soon - Multi-tiered verification system for hazard reports</p>
          </div>
        );
      case 'community':
        return (
          <div className="p-6">
            <h1 className="text-3xl mb-4">Community Hub</h1>
            <p className="text-gray-600">Coming soon - Community moderation and engagement tools</p>
          </div>
        );
      default:
        return <MapDashboard />;
    }
  };

  const isDashboardView = currentView === 'dashboard';

  return (
    <div className="h-screen flex bg-gray-50">
      <Sidebar 
        activeView={currentView}
        onViewChange={setCurrentView}
        userRole={userRole}
      />
      
      <main className="flex-1 overflow-auto lg:ml-0">
        {isDashboardView ? (
          renderView()
        ) : (
          <div className="p-6">
            {renderView()}
          </div>
        )}
      </main>

      {/* Demo Role Switcher */}
      <div className="fixed bottom-6 right-6 z-50">
        <div className="bg-white border border-blue-200 rounded-xl p-4 shadow-xl">
          <p className="text-xs text-gray-600 mb-3 tracking-wide">Demo: Switch Role</p>
          <div className="flex flex-col space-y-2">
            {(['citizen', 'official', 'moderator'] as UserRole[]).map((role) => (
              <button
                key={role}
                onClick={() => {
                  setUserRole(role);
                  setCurrentView(role === 'citizen' ? 'report' : 'dashboard');
                }}
                className={`px-3 py-2 text-xs rounded-lg transition-all duration-200 capitalize ${
                  userRole === role 
                    ? 'bg-gradient-to-r from-blue-600 to-cyan-600 text-white shadow-md' 
                    : 'bg-blue-50 text-blue-700 hover:bg-blue-100'
                }`}
              >
                {role}
              </button>
            ))}
          </div>
        </div>
      </div>

      <Toaster />
    </div>
  );
}