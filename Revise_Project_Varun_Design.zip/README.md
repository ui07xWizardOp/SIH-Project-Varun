
  # Revise Project Varun Design

  This is a code bundle for Revise Project Varun Design. The original project is available at https://www.figma.com/design/tDbQNiqiRnEQfBpcTQSE37/Revise-Project-Varun-Design.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  